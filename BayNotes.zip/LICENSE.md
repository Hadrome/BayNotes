---

### 2. 项目技术上下文文档 (`AI_CONTEXT.md`)

这是一个专门写给“未来的我”看的文档。当你下次要把代码发给 AI 进行修改时，**先把这个文件的内容发出来**，AI 就能在几秒钟内完全掌握项目逻辑，无需你反复解释。

```markdown
# BayNotes Project Context (AI 助手专用)

此文档用于帮助 AI 快速理解 BayNotes 项目的架构、逻辑和当前状态。

## 1. 架构概览
* **类型**: 单页应用 (SPA) + Serverless 后端。
* **部署**: Cloudflare Pages + Functions。
* **数据库**: Cloudflare D1 (SQLite)。
* **前端**: 原生 HTML/JS, Vue 3 (Options API), Tailwind CSS (CDN), CryptoJS (AES), Marked (Markdown)。
* **鉴权**: 自定义 Token (Bearer Header)，Token 格式 `base64(userId:uuid)`，存储于 localStorage。

## 2. 核心数据结构 (D1 SQL Schema)
* **`users`**: `id`, `username`, `password_hash`, `salt`, `role` (admin/user), `permissions` (text: 'edit,delete,share...').
* **`notes`**: 
    * 基础: `id`, `user_id`, `title`, `content`.
    * 归档: `folder_id` (关联 folders 表).
    * 安全: `is_encrypted` (1/0, 若为 1，则 content 存储 AES 密文).
    * 分享: `share_id` (唯一), `share_pwd`, `share_expire_at`, `share_burn_after_read`.
    * 软删除: `deleted_at` (非空即为在回收站).
* **`folders`**: `id`, `user_id`, `name`, `parent_id` (支持最多 2 级嵌套).

## 3. 关键业务逻辑

### 加密策略 (Encryption)
* **模式**: 客户端侧加密 (Client-side) + 服务端存储。
* **逻辑**: 
    * 用户设置密码 -> 前端使用 AES 加密 content -> 后端仅存储密文。
    * 查看时 -> 前端提示输入密码 -> 内存中解密展示 (不保存密码到服务器)。
    * `notes.js` API 仅负责透传 `is_encrypted` 状态和 content 字符串，不处理加密运算。

### 分享系统 (Sharing)
* **生成**: 用户在主页配置参数 -> `PATCH /api/notes` 生成 `share_id`。
* **访问**: 访客访问 `view.html?id=xxx` -> 调用 `GET /api/share`。
* **阅后即焚**: 访客 API 请求成功后，后端立即触发 SQL `UPDATE notes SET share_id = NULL`。
* **分享页解密**: `view.html` 包含独立解密逻辑，若 API 返回 `is_encrypted=1`，前端弹窗要求访客输入密码进行解密。

### 权限与管理 (Admin)
* **管理员**: `role='admin'` 或用户名匹配环境变量 `SUPER_USER`。
* **Admin API**: `GET/POST/DELETE /api/admin` 用于查看用户列表、重置用户密码、修改用户权限字符串。

## 4. 文件映射
* `index.html`: 主程序。包含 Sidebar, NoteList, Editor, AuthModal, EncryptionModal, AdminPanel。
* `view.html`: 轻量级分享页。包含 SharePasswordModal, ContentDecryptModal。
* `functions/api/notes.js`: 核心业务。处理 `type=all|trash|folder|search` 查询参数。
* `functions/api/folders.js`: 文件夹增删查。

## 5. 当前开发状态 (v2.0 Enhanced)
* 已实现 Notion 风格三栏布局。
* 已实现单笔记独立密码加密。
* 已修复分享页无法查看加密笔记的 Bug。
* 搜索功能已过滤加密内容。